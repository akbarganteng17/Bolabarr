-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2024 at 08:41 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artikel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `isi` text NOT NULL,
  `tanggal_dibuat` datetime NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`id`, `user_id`, `judul`, `deskripsi`, `isi`, `tanggal_dibuat`, `gambar`, `slug`, `kategori`) VALUES
(24, 1, 'indonsia', 'asdasdasdasd', 'Bola.com, Jakarta - Tiga peserta anyar yang berstatus sebagai tim promosi di Liga 1 musim depan layak dinantikan kiprahnya. Setelah berhasil naik ke kasta tertinggi, pergerakan mereka juga patut diikuti.\r\n\r\nKetiga tim promosi yang dimaksud yakni Malut United, PSBS Biak, hingga Semen Padang. Kiprah mentereng mereka di Liga 2 musim ini tentu harus diikuti dengan persiapan yang matang jika ingin bisa bersaing di Liga 1 2024/2025.\r\n\r\nEnam+11:22VIDEO: Wawancara Eksklusif Ousmane Maiket Camara, Pemain Berdarah Guinea dengan Mimpi Besar untuk Timnas Indonesia\r\n)', '2024-06-09 09:35:09', 'uploads/072104200_1709986850-20240309AA_Malut_United_Vs_Persiraja_Banda_Aceh-2.webp', 'indonsia', 'liga_indonesia'),
(25, 1, 'Ada Penolakan di Blitar, Arema FC Kembali Pusing Urusan Homebase Musim Depan', 'encana Arema FC menggunakan Stadion Soepriadi, Blitar, sebagai homebase di  Liga 1 musim 2024/2025 menemui jalan buntu. ', 'Bola.com, Malang - Rencana Arema FC menggunakan Stadion Soepriadi, Blitar, sebagai homebase di  Liga 1 musim 2024/2025 menemui jalan buntu. Ada Kekhawatiran di benak masyarakat jika Arema FC bermain di Blitar.\r\n\r\nWali Kota Blitar, Santoso, mengaku belum bisa menerima kehadiran tim berjulukan Singo Edan itu di kotanya pada  Liga 1 musim depan. Tragedi Kanjuruhan di Malang pada 2022 dan insiden ricuh semifinal Piala Gubernur Jatim 2020 di Blitar masih meninggalkan trauma.\r\n\r\nEnam+05:18VIDEO Vlog Bola: Sensasi Nonton Timnas Indonesia Vs Irak dari Tribune Penononton\r\nAdvertisement\r\n\r\n\r\n\r\n\"Kami sudah menerima surat permohonan untuk menggunakan Stadion Soepriadi. Namun, trauma masyarakat masih belum hilang,\" ujar Santoso.\r\n\r\nSeperti diketahui, tragedi Kanjuruhan memakan korban jiwa hingga 135 orang. Tragedi itu terjadi setelah pertandingan melawan Persebaya Surabaya di Liga 1.\r\n\r\nDampak bagi warga Blitar memang tidak langsung, tetapi mereka khawatir ada insiden seperti itu lagi terulang jika Arema FC bermain di Blitar.\r\n\r\nYuk gabung channel whatsapp Bola.com untuk mendapatkan berita-berita terbaru tentang Timnas Indonesia,  BRI Liga 1 Liga 1, Liga Champions, Liga Inggris, Liga Italia, Liga Spanyol, bola voli, MotoGP, hingga bulutangkis. Klik di sini (JOIN)', '2024-06-09 10:17:57', 'uploads/037753700_1592898671-Arema_FC_-_Ilustrasi_Logo.webp', 'ada-penolakan-di-blitar-arema-fc-kembali-pusing-urusan-homebase-musim-depan', 'liga_indonesia'),
(26, 1, ' Tim Nasional Indonesia merupakan hasil seleksi pemain-pemain sepakbola terbaik berkebangsaan IndonesiaTimnas Indonesia BRI Liga 1 merupakan sebuah liga sepak bola divisi tertinggi yang ada di IndonesiaBRI Liga 1 Persib Bandung adalah klub sepakbola asal ', 'Liga 1 2024/2025 baru akan dimulai pada 2 Agustus mendatang. Saat ini klub kontestan liga level tertinggi di Indonesia itu disibukkan dengan aktivitas di bursa transfer.', 'Bola.com, Jakarta - Liga 1 2024/2025 baru akan dimulai pada 2 Agustus mendatang. Saat ini klub kontestan liga level tertinggi di Indonesia itu disibukkan dengan aktivitas di bursa transfer.\r\n\r\nMalut United adalah salah satu klub Liga 1 yang cukup sibuk di bursa transfer. Minggu, (9/6/2024) siang WIB, manajemen Naga Gamalama mengumumkan kehadiran pemain asing baru.\r\n\r\nEnam+05:18VIDEO Vlog Bola: Sensasi Nonton Timnas Indonesia Vs Irak dari Tribune Penononton\r\nAdvertisement\r\n\r\n\r\n\r\nSosok yang dimaksud adalah Tatsuro Nagamatsu. Pemain asal Jepang berusia 29 tahun itu digaet dari klub Malta, Santa Lucia FC.\r\n\r\nMalut United memberikan kontrak selama satu tahun untuk Tatsuro Nagamatsu. Pemain yang berposisi sebagai gelandang serang ini diperkirakan akan menjadi andalan baru skuad asuhan Imran Nahumarury.\r\n\r\n\"Tatsuro Nagamatsu menandatangani kontrak selama satu tahun. Ia bergabung bersama Malut United setelah masa pengabdiannya di Santa Lucia FC, klub anggota Divisi I di Malta, berakhir pada 24 Mei 2024,\" bunyi rilis resmi dari Malut United.\r\n\r\n\r\nYuk gabung channel whatsapp Bola.com untuk mendapatkan berita-berita terbaru tentang Timnas Indonesia, BRI Liga 1, Liga Champions, Liga Inggris, Liga Italia, Liga Spanyol, bola voli, MotoGP, hingga bulutangkis. Klik di sini (JOIN)\r\n\r\n2 dari 4 halaman\r\nPemain Spesial\r\nFOTO Malut United FC\r\nPelatih kepala Malut United FC, Imran Nahumarury saat memberikan arahan kepada para pemain. (Bola.com/Dok Malut United FC)\r\nTatsuro Nagamatsu memang masih asing di telinga pencinta sepak bola Indonesia. Hal itu diakui oleh Imran Nahumarury.\r\n\r\nNamun, Imran Nahumarury meyakini pemain satu ini cukup spesial. Nagamatsu diyakini juga akan berkontribusi besar untuk Malut United.\r\n\r\n\"Mungkin tak banyak pencinta sepak bola di Indonesia yang akrab dengan nama Tatsuro Nagamatsu. Tetapi, tim pelatih Malut United yakin dan percaya gaya bermain Tatsuro cocok untuk tim dan ia akan berkontribusi maksimal,\" kata Imran Nahumarury.\r\n\r\n\r\n\r\n\r\nPemain Asing Pertama\r\nImran Nahumarury - Persiraja Banda Aceh Vs Semen Padang di leg pertama Playoff Pegadaian Liga 2 2023/2024\r\nImran Nahumarury - Persiraja Banda Aceh Vs Semen Padang di leg pertama Playoff Pegadaian Liga 2 2023/2024, Selasa (5/3/2024). (Dok. Malut United)\r\nTatsuro Nagamatsu menjadi pemain asing pertama yang digaet Malut United untuk menghadapi Liga 1 2024/2025. Ekspektasi untuk pemain berusia 29 tahun itu pun cukup tinggi.\r\n\r\nSeperti yang diungkapkan oleh Willem D. Nanlohy, selaku COO Malut United. Ia berharap Nagamatsu cepat beradaptasi dengan iklim sepak bola di Indonesia.\r\n\r\n\"Kami memilih Tatsuro Nagamatsu sebagai pemain asing Malut United asal Asia. Semoga dia cepat menyesuaikan diri dan memenuhi ekspektasi untuk membawa Laskar Kie Raha meraih hasil terbaik di Liga 1,\" ucap Willem D. Nanlohy, COO Malut United.', '2024-06-09 10:19:31', 'uploads/045547000_1717910408-Rekrutan_anyar_dari_Jepang__Tatsuro_Nagamatsu__setelah_menandatangani_kontrak_bersama_Malut_United_FC.webp', '-tim-nasional-indonesia-merupakan-hasil-seleksi-pemain-pemain-sepakbola-terbaik-berkebangsaan-indonesiatimnas-indonesia-bri-liga-1-merupakan-sebuah-liga-sepak-bola-divisi-tertinggi-yang-ada-di-indonesiabri-liga-1-persib-bandung-adalah-klub-sepakbola-asal-', 'liga_indonesia'),
(27, 1, 'Eks Penggawa Timnas Indonesia Setuju Kuota Pemain Asing Liga 1 Ditambah: Amunisi Lokal Jangan Takut Bersaing!', 'Kampanye para pemain Indonesia yang menolak wacana penambahan kuota pemain asing pada kompetisi Liga 1 musim depan mendapatkan respons dari mantan penggawa Timnas Indonesia, Zulkifli Syukur.', 'Bola.com, Jakarta - Kampanye para pemain Indonesia yang menolak wacana penambahan kuota pemain asing pada kompetisi Liga 1 musim depan mendapatkan respons dari mantan penggawa Timnas Indonesia, Zulkifli Syukur.\r\n\r\nDi media sosial, para pesepak bola secara serempak mengunggah gambar dengan tulisan ‘Ini Sepak Bola Indonesia, Apakah Ini Sepak Bola Indonesia?’ di akun Instagramnya masing-masing pada Jumat (7/6/2024) malam WIB.\r\n\r\nKampanye ini digalang oleh pesepak bola untuk merespons rencana PSSI dan PT Liga Indonesia Baru (LIB) yang ingin menambah kuota penggunaan pemain asing, dari enam menjadi delapan slot, pada musim depan.\r\n\r\nMantan pemain Timnas Indonesia, Zulkifli Syukur, justru memiliki sikap yang berbeda dibandingkan para juniornya dalam melihat persoalan ini. Lalu, apa kata eks bek kanan skuad Garuda itu?\r\n\r\n\r\nYuk gabung channel whatsapp Bola.com untuk mendapatkan berita-berita terbaru tentang Timnas Indonesia, BRI Liga 1, Liga Champions, Liga Inggris, Liga Italia, Liga Spanyol, bola voli, MotoGP, hingga bulutangkis. Klik di sini (JOIN)\r\n\r\n', '2024-06-09 10:20:29', 'uploads/084473700_1701772409-3_pemain_lokal_yang_bersaing_jadi_top_score_BRI_Liga_1_-_Bola.com_Salsa_Dwi_Novita__1_.webp', 'eks-penggawa-timnas-indonesia-setuju-kuota-pemain-asing-liga-1-ditambah-amunisi-lokal-jangan-takut-bersaing-', 'liga_indonesia'),
(28, 1, 'Tantangan Pemain Lokal', 'Zulkifli Syukur menjelaskan, penambahan kuota pemain asing ini semestinya tak membuat pemain lokal merasa was-was.', 'Zulkifli Syukur menjelaskan, penambahan kuota pemain asing ini semestinya tak membuat pemain lokal merasa was-was. Sebab, jika memang mereka punya kualitas, maka posisinya tak akan terancam.\r\n\r\nPemain yang pernah menjadi langganan Timnas Indonesia di periode 2010-2014 itu menyebut, bertambahnya jumlah pemain asing juga akan memberikan dampak positif pada kualitas kompetisi.\r\n\r\n“Dengan adanya rumor mengenai penambahan jumlah pemain asing untuk musim depan, saya pikir ini adalah sebuah tantangan buat seluruh pemain lokal untuk membuktikan kualitasnya,” ujar Zulkifli Syukur melalui akun Instagramnya, Jumat (7/6/2024).\r\n\r\n“Selain itu, kualitas kompetisi kita juga akan ikut terdongkrak, tetapi harus selektif juga dalam perekrutan pemain asing. Jangan karena harga murah, tapi kualitas dikesampingkan,” tambahnya.', '2024-06-09 10:24:28', 'uploads/093958600_1617184409-5_20210331IQ_PSM_Makassar_VS_Borneo_FC_Samarinda04.webp', 'tantangan-pemain-lokal', 'liga_indonesia'),
(29, 1, 'Ada Godaan dari Real Madrid, Man City Bakal Bikin Phil Foden Jadi Pemain Inggris Termahal', 'Manchester City dikabarkan siap menawarkan kontrak baru dengan bayaran yang mahal untuk Phil Foden. ', 'Bola.com, Jakarta - Manchester City dikabarkan siap menawarkan kontrak baru dengan bayaran yang mahal untuk Phil Foden. Keputusan itu harus diambil oleh Man City untuk menghalau potensi kepindahan sang bintang menyusul adanya minat dari Real Madrid.\r\n\r\nPhil Foden sejauh ni telah mencatatkan 270 penampilan untuk Man City saat usianya baru menginjak 24 tahun pada akhir Mei 2024.\r\n\r\nEnam+02:24VIDEO: 4 Pemain Belanda yang Bisa Memperkuat Liverpool\r\nAdvertisement\r\n\r\n\r\n\r\nProduk akademi Man City itu telah menjadi salah satu bintang di tim utama, terbukti dengan penobatan terhadap dirinya sebagai pemain terbaik klub, berkat penampilan menakjubkan selama musim 2023/2024.\r\n\r\nDalam kompetisi domestik, pemain sayap ini mencatatkan 19 gol dan delapan assist dalam 35 penampilan untuk membantu Man City meraih gelar juara Premier League untuk kali keempat secara beruntun.\r\n\r\nTotal, Phil Foden telah mengakhiri musim 2023/2024 dengan 27 gol dan 12 assist dalam 53 pertandingan di semua kompetisi bersama skuad asuhan Pep Guardiola.\r\n\r\nYuk gabung channel whatsapp Bola.com untuk mendapatkan berita-berita terbaru tentang Timnas Indonesia, BRI Liga 1, Liga Champions, Liga Inggris, Liga Italia, Liga Spanyol, bola voli, MotoGP, hingga bulutangkis. Klik di sini (JOIN)', '2024-06-09 10:28:25', 'uploads/069548000_1639528480-1_AP21348727750291.webp', 'ada-godaan-dari-real-madrid-man-city-bakal-bikin-phil-foden-jadi-pemain-inggris-termahal', 'liga_inggris'),
(30, 1, 'Ronaldo Salto', 'akbar ganteng', 'asdasdas', '2024-06-20 07:25:34', 'uploads/NASA_logo.svg.png', 'ronaldo-salto', 'liga_inggris'),
(31, 1, 'asdasd', 'asdasd', 'asdasd', '2024-06-20 07:25:56', 'uploads/BktaZiWCMAAqb7x.jpg', 'asdasd', 'liga_spanyol'),
(44, 1, 'asdasd azzz', 'asdasd', 'asdasd', '2024-06-20 08:29:08', 'uploads/adasdasd.png', 'asdasd-azzz', 'liga_inggris');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(7, 'akbar', '$2y$10$bqjJKF4mTOraOSHyoqeSeuBEHQPaH29siUm9jLZ6uRAYxIThzwi0C'),
(8, 'akbarz', '$2y$10$y4s1SW6cN66r1O8TeIsHsuH8s0ox.wDnpjjlJ/7fzauT3jHgWSQ6C'),
(9, 'gumilang', '$2y$10$xjWU9nmBIEq1D6HaivemcuSZJ14.unzpL.uIUulc/bjctKKfUUnIi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
